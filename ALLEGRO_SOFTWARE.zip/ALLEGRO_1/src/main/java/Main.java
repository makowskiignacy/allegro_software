import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        int port = 4444;
        if (args.length == 1) {
            port = Integer.parseInt(args[0]);
        }
        Task jobGit = new Stars();
        TCP server = new TCP(port, jobGit);
        server.run();
    }
}