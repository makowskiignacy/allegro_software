public abstract class Server {
    protected int port;
    protected Task task;
    public abstract void run();
}
