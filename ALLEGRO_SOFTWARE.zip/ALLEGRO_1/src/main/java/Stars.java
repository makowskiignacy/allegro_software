import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GHUser;
import org.kohsuke.github.GitHub;

import java.io.IOException;

public class Stars extends Task{
    public Stars() throws IOException {
        git = GitHub.connect();
    }

    @Override
    public String handle(String question) {
        GHUser usr;
        try {
            usr = git.getUser(question);
        } catch (IOException e) {
            return "User not found\n";
        }
        if (usr == null) {
            return "User not found\n";
        }
        StringBuilder answer = new StringBuilder();
        int starSum = 0;
        for (GHRepository r : usr.listRepositories()) {
            answer.append("Library: ").append(r.getName()).append(' ').append(r.getStargazersCount()).append('\n');
            starSum += r.getStargazersCount();
        }
        answer.append("SUM OF USER STAR ").append(starSum).append('\n');
        return answer.toString();
    }
}