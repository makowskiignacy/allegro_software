import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class TCP extends Server {
    public TCP(int p, Task t) {
        port = p;
        task = t;
    }
    @Override
    public void run() {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            Socket socket = serverSocket.accept();
            InputStream inputStream = socket.getInputStream();
            OutputStream outputStream = socket.getOutputStream();
            Scanner scanner = new Scanner(inputStream, StandardCharsets.UTF_8);
            PrintWriter printer = new PrintWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8), true);
            boolean done = false;
            while(!done && scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if(line.toLowerCase().trim().equals("poweroff")) {
                    done = true;
                } else {
                    printer.println(task.handle(line));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
