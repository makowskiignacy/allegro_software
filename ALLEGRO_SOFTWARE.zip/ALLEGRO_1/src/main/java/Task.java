import org.kohsuke.github.GitHub;

import java.io.IOException;

public abstract class Task {
    protected GitHub git;
    public abstract String handle(String question) throws IOException;
}
